%% Second numerical simulation of the 6-DOF manipulator - Hybrid controller
%--------------------------------------------------------------------------
%  This example is part of the manuscript entitled:
% 
%  Hybrid Kinematic Control for Rigid Body Pose Stabilization using
%  Dual Quaternions
% 
%  Submitted to the Journal of the Fraklin Institute
%  Date:    November, 2016
% 
%  Authors: Hugo T. M. Kussaba      
%           Luis F. C. Figueredo
%           Joao Y. Ishihara 
%           Bruno V. Adorno
%           
%  Contact information: lfc.figueredo@gmail.com
%
%-------------------------------------------------------------------------- 
% This script requires the DQ Robotics library
%
% DQ Robotics website: http://dqrobotics.sourceforge.net/
%-------------------------------------------------------------------------- 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------- 


function [ result ] = JFIexamples1_manipulator_hyb( )

clear all;
close all;
clear classes;

% Garbage collection
java.lang.System.gc()



%% ROBOT CONFIGURATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== ROBOT CONFIGURATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
% The robot configuration is required to obtain the forward kinematic model
% and the Jacobian for this particular manipulator:
% Comau Smart Six - A six DOF manipulator.
% The FKM model and the Jacobian have been calculated using the dq_robotics
% toolbox and are defined in accordance to the thesis:
%        B. V. Adorno, Two-arm Manipulation: From Manipulators to Enhanced
%        Human-Robot Collaboration, Ph.D. thesis, Lab. d’Informatique, de
%        Robotique et de Microélectronique de Montpellier (LIRMM) -
%        Université Montpellier 2, Montpellier, France, 2011.   
% 
comau_DH_theta=  [0, -pi/2, pi/2, 0, 0, 0, pi];
comau_DH_d =     [-0.45, 0, 0, -0.64707, 0, -0.095, 0];
comau_DH_a =     [0, 0.150, 0.590, 0.13, 0, 0, 0];
comau_DH_alpha = [pi, pi/2, pi, -pi/2, -pi/2, pi/2, pi];
comau_dummy =    [0,0,0,0,0,0,1];
comau_DH_matrix = [comau_DH_theta;
    comau_DH_d;
    comau_DH_a;
    comau_DH_alpha;
    comau_dummy];
comau_kine = DQ_kinematics(comau_DH_matrix, 'modified');
assignin('base','comau_kine',comau_kine)






%% INIT CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== INIT CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
% In this particular example, we are setting the serial manipulator joints
% to a configuration to a previously known configuration 
% The same ideia is valid for the desired configuration
initial_theta = [ -0.9425    0.6283   -1.5708         0    1.5708         0.625  ]';  
desired_theta = [pi/2,      0,          -pi/2,      0,    pi/2,    0]';

% From this initial joint configuration, we extract the initial pose and
% desired pose configuration using the unit dual quaternion representation
% and the robot known forward kinematics.
xd = comau_kine.fkm(desired_theta);
xm = comau_kine.fkm(initial_theta);

% The error is defined in accordance to the definition presented in the
% authors previous paper: 
%     L. F. C. Figueredo, B. V. Adorno, J. Y. Ishihara and G. A. Borges, 
%     "Robust kinematic control of manipulator robots using dual quaternion
%     representation,"
%     IEEE International Conference on Robotics and Automation (ICRA),
%     2013, pp. 1949-1955. doi: 10.1109/ICRA.2013.6630836. 
%     URL: http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=6630836&isnumber=6630547
qe = vec8(DQ(1)-xm'*xd);



%% OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================



%%% Simulation Time (s)  PS.: This is not the simulation duration
MAX_TIME =200;

%%% Noise: A vector of random variables (Gaussian with zero mean and std
%%%        equal to 1) is obtained offline in order to improve the
%%%        simulation efficiency and reduce its duration
noise = randn(10000000,1);    
noise_aux = size(noise,1);   


%%% Control Gain Value
GAINk = 0.020;

%%% Value for the hysteris region
HYST_SIZE = 0.10;





%% RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

%%%%%%%%%%%%============[ SOLVER ]=========================
    
disp('========================================')
disp('======     STARTING SIMULATION    ======')    
disp('========================================')
tic    
initVecAug=initial_theta;

    disp([10,'=======================',10,'  HYBRID CONTROLLER ',10,'=======================',])
    hyst = 1;
    optionsSIm=odeset('AbsTol',0.1e-3,'Stats','off','Events',@events); 


    tstart = 0;
    tout = 0;
    yout = initVecAug;
    teout = [];
    yeout = [];
    ieout = [];
    jumps = [];
    for indexloop = 1:5000   % Maximum number of jumps                      
        % Solve until the first terminal event.
        % [te,ye,ie] => time, output(y) and index at the time of the event ocorrence 
        [T,Y,te,ye,ie] = ode45(@(T,Y) comauContinuous_hybrid(T,Y),[tstart MAX_TIME],[initVecAug],optionsSIm);

        % Accumulate output.  This could be passed out as output arguments.
        nt = length(T);
        tout = [tout; T(2:nt)];
        yout = [yout  Y(2:nt,:)'];
        teout = [teout; te];          
        yeout = [yeout ye'];
        ieout = [ieout; ie];


        % Set the new initial condition (after switching)
        hyst = -hyst;
        % A good guess of a valid first timestep is the length of the last valid
        % timestep, so use it for faster computation.  'refine' is 4 by default.
        optionsSIm=odeset('AbsTol',0.1e-3,'Stats','off','Events',@events, ...
                          'InitialStep',T(nt)-T(nt-4), ...
                          'MaxStep',T(nt)-T(1)); 

        tstart = T(nt);
        initVecAug = Y(nt,:);
        if tstart >= MAX_TIME
            break
        end        
        disp([10,'===> Switch n',num2str(indexloop),' at time t=',num2str(tstart),'.'])
    end
    T = tout;
    Y = yout';
    jumps.teout = teout;
    jumps.yeout = yeout;
    jumps.ieout = ieout;
        
toc    
disp('========================================')



%%%%%%====> Calculate additional information from the simulated scenario
sim = dinamCalc();
confinfo.maxtime = MAX_TIME;
confinfo.initial_theta = initial_theta;
confinfo.desired_theta = desired_theta;
confinfo.noise = noise;
confinfo.noise_aux = noise_aux;
confinfo.gain = GAINk;
sim.conf = confinfo;
sim.jumps = jumps;
for ix = 1:length(T)
    temp_index = ceil((100000-1)*T(ix))+1;
    temp_mult=0.1;
    while (temp_index  > noise_aux)
        temp_index = ceil((temp_mult*100000-1)*T(ix))+1;
        temp_mult = temp_mult*0.1;
    end
    sim.noise(ix) = 0.30*noise( temp_index );        
end

%%%%%%====> Saving the simulated data in the workspace
assignin('base','sim',sim);    
    

%%%%%%%%%%%%============[ GRAFICOS ]=========================
display('MANIPULATOR MOTION...')
plotGraphs();

%%%%%%%%%%%%###############################################################
%%%%%%%%%%%%============[ END OF THE SIMULATION  ]=========================
%%%%%%%%%%%%###############################################################
display('PROGRAM END')
disp('########################################')
disp(' ')






%% FUNCTION: THETA'S CONTINUOUS EVOLUTION  -- HYBRID controller
%%%%%%%%%%%%%%%%%%%%%%%%%%%%================== THETA'S CONTINUOUS EVOLUTION 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
 function [ dy ] = comauContinuous_hybrid(t,thetax)     

    % NOISE: Obtaining the noise data in accordance to the the sim time
    index = ceil((100000-1)*t)+1;
    mult=0.1;
    while (index  > noise_aux)
        index = ceil((mult*100000-1)*t)+1;
        mult = mult*0.1;
    end
    % Setting the noise covariance
    m = 0.30*noise( index );

   
    % Kinematic data from the Manipulator
    xm = comau_kine.fkm(thetax); 
    xe = xm'*xd;
    J8 = comau_kine.jacobian(thetax);    
    for ij=1:6
        Jw8(:,ij) = vec8( DQ( J8(:,ij) )*xm' ); 
    end
    Jw = Jw8([2:4,6:8],:);                      
    %invjacob = Jw'*(inv(Jw*Jw'+0.0001*eye(6)));
    invjacob = pinv(Jw);    
    
    

    % Hybrid Controller
    q = xe.q;
    % applies random noise to primary part and normalize again
    n1n = q(1) + m;   
    % Noised measurement (normalized)    
    xmunc = DQ(1); 
    xmunc.q = [n1n;q(2:end)];    
    h=norm(xmunc);  
    xmunc = xmunc*( (1/h.q(1))*( 1 - DQ.E*(h.q(5)/h.q(1)) ) );
    qe = xmunc; 
    n1 = xe.q(1);    e1 = xe.q(2:4);
    n2 = xe.q(5);    e2 = xe.q(6:8);   
    s1 = -2*hyst*GAINk*(e1); 
    s2 = -2*GAINk*n1*e2;        
    temp = xe'*DQ([0;s1;0;s2])*xe;      
    twistEndEFF = -xd*temp*xd';
    
    % Theta velocity as the kinematic control output
    dy = invjacob*twistEndEFF.q([2:4,6:8],:);
     
 end



function [value,isterminal,direction] = events(t,thetax)
    
    % NOISE: Obtaining the noise data in accordance to the the sim time
    index = ceil((100000-1)*t)+1;
    mult=0.1;
    while (index  > noise_aux)
        index = ceil((mult*100000-1)*t)+1;
        mult = mult*0.1;
    end
    % Setting the noise covariance
    m = 0.30*noise( index );    
    
    % Kinematic data from the Manipulator    
    xm = comau_kine.fkm(thetax); 
    xe = xm'*xd;    
    q = xe.q;
    % applies random noise to primary part and normalize again
    n1n = q(1) + m;   
         
    % Locate the time when n1n*hyst + HYST_SIZE passes through zero stop
    % integration. This is exactly the point where jumpa occur
    value = n1n*hyst + HYST_SIZE ;     % Detect = 0
    isterminal = 1;   % Stop the integration
    direction = 1;    % Negative direction only

end










%% FUNCTION: ERROR CALCULATION AND ASSIGNIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== ERROR CALCULATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
function [ sim ] = dinamCalc()
   sim.tam = length(T); 
   sim.time = T;   
   sim.theta = Y;  
   sim.q.qd = xd;  sim.q.qm =[];        sim.q.qmVec8 =[];  
   sim.qe=[];      sim.qeNorm=[];    

   %%%==> Errors:     
    for i=1:size(Y,1)
      
        % Evolution of q                
        qdin(i) = comau_kine.fkm(Y(i,:));          
        sim.q.qm     =[sim.q.qm      qdin(i)];
        sim.q.qmVec8 =[sim.q.qmVec8  vec8(qdin(i))];
        % Error given current q
        qe = vec8(qdin(i)'*xd);
        sim.qe = [sim.qe  qe];                           
        % Error norm
        sim.qeNorm = [sim.qeNorm  norm(qe)];         
        
    end
    
    
   %%%==> END EFFECT - POS and ANGLES:   
   firstQuat =sim.q.qd.q(1:4);
   seconQuat =sim.q.qd.q(5:8);
%    desiredPos = quatmultiply(2*seconQuat',quatconj(firstQuat'));
   desiredPos = quatmultiply(2*quatconj(firstQuat'),seconQuat');
   
   sim.position.qm = [];
   sim.position.qd = desiredPos;
    for i=1:size(sim.q.qm,2)
      
        dqQuat=sim.q.qm(i); 
        firstQuat =dqQuat.q(1:4);
        seconQuat =dqQuat.q(5:8);   
%         actualPos = quatmultiply(2*seconQuat',quatconj(firstQuat'));
        actualPos = quatmultiply(2*quatconj(firstQuat'),seconQuat');        
        sim.position.qm = [sim.position.qm; actualPos];
       
    end
    
   sim.position.qe = (sim.position.qd'*ones(1,length(sim.time)) - sim.position.qm')';
   sim.position.errornorm = sum((sim.position.qe.^2),1).^0.5;

end




%% SIMULATION VIEWER 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== PLOT VIEWER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

function [] = plotGraphs()
      
        figId = figure;
        hold on;
    
        axis equal;    
        grid off;  
        view(-30,45)
        plot(comau_kine, [sim.theta(1,:)']');        
        
        plot(xd,'scale',1);
               
        axis equal;
        axis([-0.8,1.2,-0.8,0.8,-0.2,1.5]);
        view(27,34);
        zoom(1.5);

        disp([10,9,'*** Initial pose: Please press space to continue..'])
        pause         
        plot(comau_kine, [desired_theta]');        
        disp([10,9,'*** Desired pose: Please press space to continue..'])
        pause
        plot(comau_kine, [sim.theta(1,:)']');        
        disp([10,9,'*** Initial pose: Starting simulation viewer in 1 seg.'])
        pause(1)
        

        for iloopplot=1:(4):size(sim.theta,1) %size(sim.theta,1)
            plot(comau_kine, [sim.theta(iloopplot,:)']');  
%             pause(0.0001)                           
        end
       
end




end