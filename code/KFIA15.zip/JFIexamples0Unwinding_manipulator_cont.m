%% First numerical simulation of the 6-DOF manipulator - Continuous controller 
%--------------------------------------------------------------------------
%  This example is part of the manuscript entitled:
% 
%  Hybrid Kinematic Control for Rigid Body Pose Stabilization using
%  Dual Quaternions
% 
%  Submitted to the Journal of the Fraklin Institute
%  Date:    November, 2016
% 
%  Authors: Hugo T. M. Kussaba      
%           Luis F. C. Figueredo
%           Joao Y. Ishihara 
%           Bruno V. Adorno
%           
%  Contact information: lfc.figueredo@gmail.com
%
%-------------------------------------------------------------------------- 
% This script requires the DQ Robotics library
%
% DQ Robotics website: http://dqrobotics.sourceforge.net/
%-------------------------------------------------------------------------- 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------- 



function JFIexamples0Unwinding_manipulator_cont(init_theta)

close all;

% Garbage collection
java.lang.System.gc()



%% ROBOT CONFIGURATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== ROBOT CONFIGURATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
% The robot configuration is required to obtain the forward kinematic model
% and the Jacobian for this particular manipulator:
% Comau Smart Six - A six DOF manipulator.
% The FKM model and the Jacobian have been calculated using the dq_robotics
% toolbox and are defined in accordance to the thesis:
%        B. V. Adorno, Two-arm Manipulation: From Manipulators to Enhanced
%        Human-Robot Collaboration, Ph.D. thesis, Lab. d’Informatique, de
%        Robotique et de Microélectronique de Montpellier (LIRMM) -
%        Université Montpellier 2, Montpellier, France, 2011.   
% 
comau_DH_theta=  [0, -pi/2, pi/2, 0, 0, 0, pi];
comau_DH_d =     [-0.45, 0, 0, -0.64707, 0, -0.095, 0];
comau_DH_a =     [0, 0.150, 0.590, 0.13, 0, 0, 0];
comau_DH_alpha = [pi, pi/2, pi, -pi/2, -pi/2, pi/2, pi];
comau_dummy =    [0,0,0,0,0,0,1];
comau_DH_matrix = [comau_DH_theta;
    comau_DH_d;
    comau_DH_a;
    comau_DH_alpha;
    comau_dummy];
comau_kine = DQ_kinematics(comau_DH_matrix, 'modified');
assignin('base','comau_kine',comau_kine)






%% INIT CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== INIT CONFIG
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
% In this particular example, we are setting the serial manipulator joints
% to a random configuration. The desired configuration is the antipodal
% point, that is, xd = -xm with a small measurement noise.
if ~exist('init_theta')    
    initial_theta = randn(6,1);      
else
    initial_theta = init_theta;
%     inittheta_example = [ -0.1190    0.6796   -0.4951    0.4016    0.7837   -1.1981];
end



% From this initial joint configuration, we extract the initial pose and
% desired pose configuration using the unit dual quaternion representation
% and the robot known forward kinematics.
xm = comau_kine.fkm(initial_theta);
xd = -comau_kine.fkm(initial_theta+0.001*randn(6,1));


% The error is defined in accordance to the definition presented in the
% authors previous paper: 
%     L. F. C. Figueredo, B. V. Adorno, J. Y. Ishihara and G. A. Borges, 
%     "Robust kinematic control of manipulator robots using dual quaternion
%     representation,"
%     IEEE International Conference on Robotics and Automation (ICRA),
%     2013, pp. 1949-1955. doi: 10.1109/ICRA.2013.6630836. 
%     URL: http://ieeexplore.ieee.org/stamp/stamp.jsp?tp=&arnumber=6630836&isnumber=6630547
qe = vec8(DQ(1)-xm'*xd);



%% OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

%%% Simulation Time (s)  PS.: This is not the simulation duration
MAX_TIME =0.5;

%%% Control Gain Value
GAINk = 5;


%% RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================


%%%%%%%%%%%%============[ SOLVER ]=========================
    
disp('========================================')
disp('======     STARTING SIMULATION    ======')    
disp('========================================')
tic    
initVecAug=initial_theta;
optionsSIm=odeset('AbsTol',10e-3,'Stats','on'); 
disp([10,'=======================',10,'  Continuous Controller   ',10,'=======================',])
disp([10,'   * Init cond.: ']),  xm
disp([10,'   * Final cond.: ']), xd
[T,Y] = ode45(@comauContinuous_Continuous,[0 MAX_TIME],[initVecAug],optionsSIm);        
toc    
disp('========================================')



%%%%%%====> Calculate additional information from the simulated scenario
sim = dinamCalc();
confinfo.maxtime = MAX_TIME;
confinfo.initial_theta = initial_theta;
confinfo.gain = GAINk;
sim.conf = confinfo;


%%%%%%====> Saving the simulated data in the workspace
assignin('base','sim',sim);    
    

%%%%%%%%%%%%============[ GRAFICOS ]=========================
display('MANIPULATOR MOTION...')
plotGraphs();

%%%%%%%%%%%%###############################################################
%%%%%%%%%%%%============[ END OF THE SIMULATION  ]=========================
%%%%%%%%%%%%###############################################################
display('PROGRAM END')
disp('########################################')
disp(' ')








%% FUNCTION: THETA'S CONTINUOUS EVOLUTION  -- Continuous controller
%%%%%%%%%%%%%%%%%%%%%%%%%%%%================== THETA'S CONTINUOUS EVOLUTION 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
 function [ dy ] = comauContinuous_Continuous(t,thetax)     
    
    % Kinematic data from the Manipulator
    xm = comau_kine.fkm(thetax); 
    xe = xm'*xd;
    J8 = comau_kine.jacobian(thetax);    
    for ij=1:6
        Jw8(:,ij) = vec8( DQ( J8(:,ij) )*xm' ); 
    end
    Jw = Jw8([2:4,6:8],:);                      
    %invjacob = Jw'*(inv(Jw*Jw'+0.0001*eye(6)));
    invjacob = pinv(Jw);
       

    % Continuous Controller
    q = xe.q;
% % %     % applies random noise to primary part and normalize again
% % %     n1n = q(1) + m;   
% % %     % Noised measurement (normalized)
% % %     xmunc = DQ(1); 
% % %     xmunc.q = [n1n;q(2:end)];    
% % %     h=norm(xmunc);  
% % %     xmunc = xmunc*( (1/h.q(1))*( 1 - DQ.E*(h.q(5)/h.q(1)) ) );  
% % %     



%     if(q(1) >= 0), 
%         twistCtrl = -(2*GAINk*(xe'*log(xe)*xe));      
%     else
%         twistCtrl = -(2*GAINk*(xe'*log(-xe)*xe));     
%     end  
    
    twistCtrl = -(2*GAINk*(xe'*log(xe)*xe));      
    twistEndEFF = -xd*twistCtrl*xd';
    
    % Theta velocity as the kinematic control output
    dy = invjacob*twistEndEFF.q([2:4,6:8],:);
 
 end










%% FUNCTION: ERROR CALCULATION AND ASSIGNIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== ERROR CALCULATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
function [ sim ] = dinamCalc()
   sim.tam = length(T); 
   sim.time = T;   
   sim.theta = Y;  
   sim.q.qd = xd;  sim.q.qm =[];        sim.q.qmVec8 =[];  
   sim.qe=[];      sim.qeNorm=[];    

   %%%==> Errors:     
    for i=1:size(Y,1)
      
        % Evolution of q                
        qdin(i) = comau_kine.fkm(Y(i,:));          
        sim.q.qm     =[sim.q.qm      qdin(i)];
        sim.q.qmVec8 =[sim.q.qmVec8  vec8(qdin(i))];
        % Error given current q
        qe = vec8(qdin(i)'*xd);
        sim.qe = [sim.qe  qe];                           
        % Error norm
        sim.qeNorm = [sim.qeNorm  norm(qe)];         
        
    end
    
    
   %%%==> END EFFECT - POS and ANGLES:   
   firstQuat =sim.q.qd.q(1:4);
   seconQuat =sim.q.qd.q(5:8);
%    desiredPos = quatmultiply(2*seconQuat',quatconj(firstQuat'));
   desiredPos = quatmultiply(2*quatconj(firstQuat'),seconQuat');
   
   sim.position.qm = [];
   sim.position.qd = desiredPos;
    for i=1:size(sim.q.qm,2)
      
        dqQuat=sim.q.qm(i); 
        firstQuat =dqQuat.q(1:4);
        seconQuat =dqQuat.q(5:8);   
%         actualPos = quatmultiply(2*seconQuat',quatconj(firstQuat'));
        actualPos = quatmultiply(2*quatconj(firstQuat'),seconQuat');        
        sim.position.qm = [sim.position.qm; actualPos];
       
    end
    
   sim.position.qe = (sim.position.qd'*ones(1,length(sim.time)) - sim.position.qm')';
   sim.position.errornorm = sum((sim.position.qe.^2),1).^0.5;

end




%% SIMULATION VIEWER 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== PLOT VIEWER
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

function [] = plotGraphs()
      
        figId = figure;
        hold on;
    
        axis equal;    
        grid off;  
        view(-30,45)
        plot(comau_kine, [sim.theta(1,:)']');        
        
        plot(xd,'scale',1);
               
        axis equal;
        axis([-0.8,1.2,-0.8,0.8,-0.2,1.5]);
        view(27,34);
        zoom(1.5);

        disp([10,9,'*** Initial pose: Please press space to continue..'])
        pause         
        plot(comau_kine, [sim.theta(1,:)']');        
        disp([10,9,'*** Initial pose: Starting simulation viewer in 1 seg.'])
        pause(1)
        

        for iloopplot=1:ceil(sim.tam/30):size(sim.theta,1) %size(sim.theta,1)
            plot(comau_kine, [sim.theta(iloopplot,:)']');  
%             pause(0.0001)                           
        end
       
end




end