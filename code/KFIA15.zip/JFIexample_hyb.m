%% Hybrid controller numerical simulation
%--------------------------------------------------------------------------
%  This example is part of the manuscript entitled:
% 
%  Hybrid Kinematic Control for Rigid Body Pose Stabilization using
%  Dual Quaternions
% 
%  Submitted to the Journal of the Fraklin Institute
%  Date:    November, 2016
% 
%  Authors: Hugo T. M. Kussaba      
%           Luis F. C. Figueredo
%           Joao Y. Ishihara 
%           Bruno V. Adorno
%           
%  Contact information: lfc.figueredo@gmail.com
%
%-------------------------------------------------------------------------- 
% This script requires the DQ Robotics library
%
% DQ Robotics website: http://dqrobotics.sourceforge.net/
%-------------------------------------------------------------------------- 
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.
%-------------------------------------------------------------------------- 


function JFIexample_hyb(TIME, gain_k, INIT_POSE)
% INPUTS:
%--------------------------------------------------------------------------
%           TIME:    Simulation Time (s)  (this is not the simulation duration)
%           gain_k:  Value for the controller
%           INIT_POSE:  Initial configuration (in dual quaternions)
%--------------------------------------------------------------------------

% Garbage collection
java.lang.System.gc()




%% CHECK INPUT VARIABLES (both TIME and gain_k must be provided)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== CHECK INPUTS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
if ~exist('TIME','var') || ~exist('gain_k','var')
    error([10,9,'Please provide the proper input values: ''Time'' and ''gain_k''',10,9,9,'* TIME:    Simulation Time (s)  (this is not the simulation duration)',10,9,9,'* gain_k:  Value for the controller'])
end



%% SETTING INITIAL POSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== INITIAL POSE
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
% If the value is providede, just use it, otherwise it will be set at a
% point close to the discontinuity (that is, with eta near to 0)
if ~exist('INIT_POSE','var')
   quat_translation = DQ([0; randn(3,1)]);
   rotation_vector  = randn(3,1); 
   quat_rotation    = DQ([0.00001; rotation_vector]);
   quat_rotation    = quat_rotation*inv(norm(quat_rotation)); 
   
   INIT_POSE =  quat_rotation + DQ.E*0.5*quat_rotation*quat_translation;   
   
else
   % Checking if the value provided is actually a unit dual quaternion
    if(norm(INIT_POSE) ~= 1)
        error([10,'Error: The initial condition is not a unit dual quaternion',10]);
    end       
end




%% OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== OPTIONS
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

%%% Noise: A vector of random variables (Gaussian with zero mean and std
%%%        equal to 1) is obtained offline in order to improve the
%%%        simulation efficiency and reduce its duration
noisevec = randn(10000000,1);    
noise_aux  = size(noisevec,1);   
noise_gain = 0.3;

%%% Value for the hysteris region
HYST_SIZE = 0.30;


hyst = 1;



%% RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== RUNNING PROGRAM
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================

%%%%%%%%%%%%============[ SOLVER ]=========================
    
disp('========================================')
disp('======     STARTING SIMULATION    ======')    
disp('========================================')
tic    
initVecAug=INIT_POSE.q;

    disp([10,'=======================',10,'  HYBRID CONTROLLER ',10,'=======================',])    
    optionsSIm=odeset('AbsTol',0.1e-3,'Stats','off','Events',@events); 


    tstart = 0;
    tout = 0;
    yout = initVecAug;
    teout = [];
    yeout = [];
    ieout = [];
    jumps = [];
    for indexloop = 1:5000   % Maximum number of jumps                      
        % Solve until the first terminal event.
        % [te,ye,ie] => time, output(y) and index at the time of the event ocorrence 
        [T,Y,te,ye,ie] = ode45(@(T,Y) comauContinuous_hybrid(T,Y),[tstart TIME],[initVecAug],optionsSIm);

        % Accumulate output.  This could be passed out as output arguments.
        nt = length(T);
        tout = [tout; T(2:nt)];
        yout = [yout  Y(2:nt,:)'];
        teout = [teout; te];          
        yeout = [yeout ye'];
        ieout = [ieout; ie];


        % Set the new initial condition (after switching)
        hyst = -hyst;
        % A good guess of a valid first timestep is the length of the last valid
        % timestep, so use it for faster computation.  'refine' is 4 by default.
        optionsSIm=odeset('AbsTol',0.1e-3,'Stats','off','Events',@events, ...
                          'InitialStep',T(nt)-T(nt-4), ...
                          'MaxStep',T(nt)-T(1)); 

        tstart = T(nt);
        initVecAug = Y(nt,:);
        if tstart >= TIME
            break
        end        
        disp([10,'===> Switch n',num2str(indexloop),' at time t=',num2str(tstart),'.'])
    end
    T = tout;
    Y = yout';
    jumps.teout = teout;
    jumps.yeout = yeout;
    jumps.ieout = ieout;
        
toc    
disp('========================================')



%%%%%%====> Calculate additional information from the simulated scenario
sim = dinamCalc();
confinfo.maxtime = TIME;
confinfo.noisevec = noisevec;
confinfo.noise_aux  = noise_aux;
confinfo.noise_gain = noise_gain;
confinfo.gain = gain_k;
sim.conf = confinfo;
sim.jumps = jumps;
for ix = 1:length(T)
    temp_index = ceil((100000-1)*T(ix))+1;
    temp_mult=0.1;
    while (temp_index  > noise_aux)
        temp_index = ceil((temp_mult*100000-1)*T(ix))+1;
        temp_mult = temp_mult*0.1;
    end
    sim.noisevalue(ix) = noise_gain*noisevec( temp_index );        
end

%%%%%%====> Saving the simulated data in the workspace
assignin('base','sim',sim);    
    
%%%%%%%%%%%%###############################################################
%%%%%%%%%%%%============[ END OF THE SIMULATION  ]=========================
%%%%%%%%%%%%###############################################################
display('PROGRAM END')
disp('########################################')
disp(' ')






%% FUNCTION: THETA'S CONTINUOUS EVOLUTION  -- HYBRID controller
%%%%%%%%%%%%%%%%%%%%%%%%%%%%================== THETA'S CONTINUOUS EVOLUTION 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
 function [ dy ] = comauContinuous_hybrid(t,dq_q)     

    % NOISE: Obtaining the noise data in accordance to the the sim time
    index = ceil((100000-1)*t)+1;
    mult=0.1;
    while (index  > noise_aux)
        index = ceil((mult*100000-1)*t)+1;
        mult = mult*0.1;
    end
    % Setting the noise covariance
    m = noise_gain*noisevec( index );
           
    %===[ Hybrid Controller ]===
    % Applies random noise to primary part and normalize again
    n1n = dq_q(1) + m;   
    % Noised measurement (normalized)    
    xmunc = DQ(1); 
    xmunc.q = [n1n;dq_q(2:end)];    
    h=norm(xmunc);  
    xmunc = xmunc*( (1/h.q(1))*( 1 - DQ.E*(h.q(5)/h.q(1)) ) );
%     q = xmunc; 
    n1 = xmunc.q(1);    e1 = xmunc.q(2:4);
    n2 = xmunc.q(5);    e2 = xmunc.q(6:8);   
    s1 = -hyst*gain_k*(e1); 
    s2 = -gain_k*n1*e2;        
    twist = DQ([0;s1;0;s2]);      
%     twist = xmunc'*DQ([0;s1;0;s2])*xmunc;      
    
    dqdot = 0.5*DQ(dq_q)*twist;
    
    % Theta velocity as the kinematic control output
    dy = dqdot.q;
     
 end



function [value,isterminal,direction] = events(t,dq_q)
    
    % NOISE: Obtaining the noise data in accordance to the the sim time
    index = ceil((100000-1)*t)+1;
    mult=0.1;
    while (index  > noise_aux)
        index = ceil((mult*100000-1)*t)+1;
        mult = mult*0.1;
    end
    % Setting the noise covariance
    m = noise_gain*noisevec( index );  
    
    % Applies random noise to primary part and normalize again
    n1n = dq_q(1) + m;   
         
    % Locate the time when n1n*hyst + HYST_SIZE passes through zero stop
    % integration. This is exactly the point where jumpa occur
    value = n1n*hyst + HYST_SIZE ;     % Detect = 0
    isterminal = 1;   % Stop the integration
    direction = 1;    % Negative direction only

end










%% FUNCTION: ERROR CALCULATION AND ASSIGNIN
%%%%%%%%%%%%%%%%%%%%%%%%%%%%========================== ERROR CALCULATION
%%%%%%%%%%%%%%%%%%%%%%%%%%%%===============================================
function [ sim ] = dinamCalc()
   sim.tam = length(T); 
   sim.time = T;   
   sim.q =[];        
   sim.qVec8 = Y;  
   sim.qNorm=[];    

   %%%==> Errors:     
    for i=1:size(Y,1)
      
        % Evolution of q                         
        sim.q     =[sim.q      DQ(Y(i,:))];        
        % Error norm
        sim.qNorm = [sim.qNorm  norm(vec8(DQ(1)-sim.q(i)))];         
        
    end
    
   sim.position.q = [];
    for i=1:sim.tam
      
        dqQuat=sim.q(i); 
        firstQuat =dqQuat.q(1:4);
        seconQuat =dqQuat.q(5:8);   
        actualPos = quatmultiply(2*quatconj(firstQuat'),seconQuat');        
        sim.position.q = [sim.position.q; actualPos];
       
    end
    
   sim.position.errornorm = sum((sim.position.q.^2),1).^0.5;

end





end