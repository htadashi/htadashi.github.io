function [status, CC] = chebychev_center_box2(tau, eps, E1, E2)
% Computation of Chebychev center of UT points by Method 2
%
% Input:  tau: relaxation order of moment SDP problem
%         eps: approximation parameter of semi-algebraic set 
%         E1: upper and lower bounds for first moment
%         E2: upper and lower bounds for second moment
%
% Output: CC:  the approximated Chebychev center of the set of UT points

% Definition of upper and lower bounds for first and second moment
E1l = E1(1);
E1u = E1(2);
E2l = E2(1);
E2u = E2(2);

% Definition of variables and inequalities
mpol w1 x1 x2; 

S = [w1 >= eps, ...
     1-w1 >= eps, ...
     w1*x1 + (1-w1)*x2 - E1l >= 0,   ...
     -(w1*x1 + (1-w1)*x2 - E1u) >= 0,   ...
     w1*(x1^2) + (1-w1)*(x2^2) - E2l >= 0,   ...
     -(w1*(x1^2) + (1-w1)*(x2^2) - E2u) >= 0];   

% Computation of outerbounding box approximation
P1 = msdp(max(w1),S,tau);
[s1, max_w1] = msol(P1); 
P2 = msdp(min(w1),S,tau);
[s2, min_w1] = msol(P2);

max_w2 = 1 - min_w1;
min_w2 = 1 - max_w2;

P3 = msdp(max(x1),S,tau);
[s3, max_x1] = msol(P3);
P4 = msdp(min(x1),S,tau);
[s4, min_x1] = msol(P4);

P5 = msdp(max(x2),S,tau);
[s5, max_x2] = msol(P5);
P6 = msdp(min(x2),S,tau);
[s6, min_x2] = msol(P6);

% Inequalities associated to Chebyshev center
mpol w1h x1h x2h r;
S = [S, w1h >= min_w1 , w1h <= max_w1, ...
        x1h >= min_x1 , x1h <= max_x1, ...
        x2h >= min_x2 , x2h <= max_x2, ...
        (w1-w1h)^2 + (x1-x1h)^2 + (x2-x2h)^2 - r^2 <=0 , ...
        r >= 0.00001];
    

% Gloptipoly configuration
mset('yalmip',true);
%mset(sdpsettings('solver','sedumi'));
mset(sdpsettings('solver','mosek'));

% Computation of Chebychev center 
P = msdp(min(r),S,3);
[s7, min_r] = msol(P);

status = s1*s2*s3*s4*s5*s6*s7;
if status ~= 1
    disp('Global optimality could not be certified numerically')
end

res = double(meas);
w1 = res(1);
w2 = 1-res(1);
x1 = res(2);
x2 = res(3);

% Debug
w1*x1 + (1-w1)*x2 - E1l >= 0 
-(w1*x1 + (1-w1)*x2 - E1u) >= 0
w1*(x1^2) + (1-w1)*(x2^2) - E2l >= 0
-(w1*(x1^2) + (1-w1)*(x2^2) - E2u) >= 0 

% Check if w2 is between [min_w2,max_w2]
w2 <= max_w2
w2 >= min_w2

% Return coordinates of Chebychev center
CC(1) = w1;
CC(2) = w2;
CC(3) = x1;
CC(4) = x2;
