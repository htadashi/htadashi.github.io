function [status,CC] = chebychev_center_box(tau, eps, E1, E2)
% Computation of Chebychev center of UT points by Method 1
%
% Input:  tau: relaxation order of moment SDP problem
%         eps: approximation parameter of semi-algebraic set 
%         E1: upper and lower bounds for first moment
%         E2: upper and lower bounds for second moment
%
% Output: CC:  the Chebychev center of the outerbounding box approximation of 
%              the set of UT points

% Definition of upper and lower bounds for first and second moment
E1l = E1(1);
E1u = E1(2);
E2l = E2(1);
E2u = E2(2);

% Definition of variables and inequalities
mpol w1 x1 x2;

S = [w1 >= eps, ...
     1-w1 >= eps, ...
     w1*x1 + (1-w1)*x2 - E1l >= 0,   ...
     -(w1*x1 + (1-w1)*x2 - E1u) >= 0,   ...
     w1*(x1^2) + (1-w1)*(x2^2) - E2l >= 0,   ...
     -(w1*(x1^2) + (1-w1)*(x2^2) - E2u) >= 0];   

% Gloptipoly configuration
mset('yalmip',true);
%mset(sdpsettings('solver','sedumi'));
mset(sdpsettings('solver','mosek'));

% Computation of outerbounding box approximation
P1 = msdp(max(w1),S,tau);
[s1, max_w1] = msol(P1); 
P2 = msdp(min(w1),S,tau);
[s2, min_w1] = msol(P2);

max_w2 = 1 - min_w1;
min_w2 = 1 - max_w2;

P3 = msdp(max(x1),S,tau);
[s3, max_x1] = msol(P3);
P4 = msdp(min(x1),S,tau);
[s4, min_x1] = msol(P4);

P5 = msdp(max(x2),S,tau);
[s5, max_x2] = msol(P5);
P6 = msdp(min(x2),S,tau);
[s6, min_x2] = msol(P6);

status = s1*s2*s3*s4*s5*s6;
if status ~= 1
    disp('Global optimality could not be certified numerically')
end    

% Computation of Chebychev center using outerbounding box approximation
CC = zeros(4,1);
CC(1) = (min_w1 + max_w1)/2;
CC(2) = (min_w2 + max_w2)/2;
CC(3) = (min_x1 + max_x1)/2;
CC(4) = (min_x2 + max_x2)/2;